#include "Stack.h"

char *pattern_Adressage_prefixe = "^\\[[A-Z]{2}:(AX|BX|CX|DX)\\]$";// MOV [ES:AX],10

void* segment_override_addressing(CPU* cpu, const char* operand)
{
    if(!matches(pattern_Adressage_prefixe, operand)) 
    {
        return NULL;
    }

        char segment[3];
        segment[0] = operand[0];
        segment[1] = operand[1];
        segment[2] = '\0';

        char registre[3];
        registre[0] = operand[3];
        registre[1] = operand[4];
        registre[2] = '\0';

    Segment *s = hashmap_get(cpu->memory_handler->allocated, segment);
    int *position = (int*)hashmap_get(cpu->context, registre);

    if(s == NULL || position == NULL) 
    {
        printf("ERROR: segment ou registre inexistant\n");
        return NULL;
    }

    if(*position >= s->size) 
    {
        printf("ERROR: position hors limites du segment\n");
        return NULL;
    }

    return load(cpu->memory_handler, segment, *position);
}

int find_free_address_strategy(MemoryHandler *handler, int size, int strategy)
{
    if (handler == NULL) 
    {
        printf("ERROR find_free_address_strategy : Parametres invalides\n");
        return -1;
    }

    Segment *segment_courant = handler->free_list;
    if(strategy == 0)
    {
        // Alloue le premier bloc m´emoire libre suffisamment grand.
        while(segment_courant)
        {
            if(segment_courant->size >= size)
            {
                afficher_segment(segment_courant);
                return segment_courant->start;
            }
            segment_courant = segment_courant->next;
        }
        return -1;
    }

    if(strategy == 1)
    {
        //Recherche le bloc m´emoire dont la taille est la plus proche de la taille demand´ee, dans l’optique de minimiser le potentiel gaspillage.
        Segment *seg_tmp = NULL;
        while (segment_courant)
        {
            if(segment_courant->size >= size && (seg_tmp == NULL || segment_courant->size < seg_tmp->size)) 
            {
                seg_tmp = segment_courant;
            }
            segment_courant = segment_courant->next;
        }
        if(seg_tmp==NULL)
        {
            printf("ERROR find_free_segment : pas de place\n");
            return -1;
        }
        afficher_segment(seg_tmp);
        return seg_tmp->start;  
    }

    if(strategy == 2)
    {
        //S´electionne le bloc avec le plus grand espace libre restant.
        Segment *seg_tmp = NULL;
        while (segment_courant)
        {
            if(segment_courant->size >= size && (seg_tmp == NULL || segment_courant->size  > seg_tmp->size)) 
            {
                seg_tmp = segment_courant;
            }
            segment_courant = segment_courant->next;
        }
        if(seg_tmp==NULL)
        {
            printf("ERROR find_free_segment : pas de place\n");
            return -1;
        }
        afficher_segment(seg_tmp);
        return seg_tmp->start; 
    }
    return -1;
}

int alloc_es_segment(CPU *cpu)
{
    int *taille = (int*)hashmap_get(cpu->context, "AX");
    int *strategy = (int*)hashmap_get(cpu->context, "BX");
    if(taille==NULL || strategy==NULL||*taille > cpu->memory_handler->total_size || (*strategy != 0 && *strategy != 1 && *strategy != 2) || *(int*)hashmap_get(cpu->context,"ES")!=-1)
    {
        if(taille==NULL)
            printf("ERROR alloc_es_segment : taille = NULL\n");

        if(strategy == NULL)
        printf("ERROR alloc_es_segment : strat = NULL\n");

        if(*taille > cpu->memory_handler->total_size )
            printf("ERROR alloc_es_segment : taille > memory_handler->total_size \n");

        if((*strategy != 0 && *strategy != 1 && *strategy != 2))
            printf("ERROR alloc_es_segment : incorect strategie\n");

        if(*(int*)hashmap_get(cpu->context,"ES")!=-1)
            printf("Segment ES deja allouer\n");

        printf("ERROR alloc_es_segment : NULL\n");

        return 0;
    }

    int start = find_free_address_strategy(cpu->memory_handler, *taille, *strategy); // Touve le segment libre selon la strategie
    if(start==-1)
    {
        // Cas ou on a pas trouver
        printf("ERROR alloc_es_segment : start\n");
        int *val_zf = (int*)hashmap_get(cpu->context, "ZF");
        *val_zf = 1;
        return 1;
    }
    if(create_segment(cpu->memory_handler, "ES", start, *taille))
    {
        // Cree le segment ES et initialise ses cases a 0
        for (int i = 0; i < *taille; i++) 
        {
            int *zero = (int *)malloc(sizeof(int));
            *zero = 0;
            store(cpu->memory_handler, "ES", i, zero);
        }

        int *val_es = (int*)hashmap_get(cpu->context, "ES");
        *val_es = start; // Pointe la val du registre ES vers le start de ce segement

        int *val_zf = (int*)hashmap_get(cpu->context, "ZF");
        *val_zf = 0;

        return 0;
    }

    printf("ERROR alloc_es_segment : ES\n");

    int *val_zf = (int*)hashmap_get(cpu->context, "ZF");
    *val_zf = 1;
    
    return 1;

}

int free_es_segment(CPU *cpu)
{
    if(cpu==NULL)
    {
        printf("ERROR free_es_segment : NULL");
        return 0;
    }  
    Segment *es_segment = (Segment*)hashmap_get(cpu->memory_handler->allocated, "ES");
    if (es_segment == NULL) 
    {
        printf("ERROR  free_es_segment : Segment ES absent\n");
        return 0;
    }
    for (int i = 0; i < es_segment->size; i++) 
    {
        void *val = load(cpu->memory_handler, "ES", i);
        free(val);
        cpu->memory_handler->memory[es_segment->start+i] = NULL;
    }
    remove_segment(cpu->memory_handler, "ES");
    int *es_val = (int*)hashmap_get(cpu->context, "ES");
    *es_val =-1;

    return 1;

}