#include "Adressage.h"

int pushvalue(CPU *cpu, int value) 
{
    if (cpu==NULL) // Cas NULL
        return -1;

    Segment *ss = (Segment*)hashmap_get(cpu->memory_handler->allocated, "SS");// Recupere SS le segement pour avoire la localisation dans la memoire(memory)
    int *val_sp = (int*)hashmap_get(cpu->context, "SP");//Recupere la val de SP (registre vers pointe vers le sommet)
    (*val_sp)--;// decremente la val de sp

    if (*val_sp < ss->start) 
    {
        printf("ERROR PUSH : stack underflow");
        return -1;
    }

    // Stock la value dans cette position 
    int *new_val = malloc(sizeof(int));
    *new_val = value;
    void *val = store(cpu->memory_handler, "SS", *val_sp - ss->start, new_val);
    if(val == NULL) 
    {
        printf("ERROR push_value : store\n");
        free(new_val);
        return -1;
    }

    return 1;
}

int pop_value(CPU *cpu, int *dest)
{
    if (cpu==NULL) 
        return -1;
    Segment *ss = (Segment*)hashmap_get(cpu->memory_handler->allocated, "SS");// Recupere SS le segement pour avoire la localisation dans la memoire(memory)
    int *val_sp = (int*)hashmap_get(cpu->context, "SP");//Recupere la val de SP (registre vers pointe vers le sommet)
    
    if (*val_sp >= ss->start+ss->size) 
    {
        //Cas ou on depasse l'espace memoire 
        printf("ERROR PUSH : stack underflow");
        return -1;
    }

    int *val = (int*)load(cpu->memory_handler, "SS", *val_sp - ss->start);//Recupere cette valeur et la reafecte dans dest
    if(val==NULL)
    {
        printf("ERROR pop_value : load\n");
        return -1;
    }
    *dest = *val;
    free(val); 
    cpu->memory_handler->memory[ss->start + (*val_sp - ss->start)] = NULL;
    (*val_sp)++;

    return 1;
}