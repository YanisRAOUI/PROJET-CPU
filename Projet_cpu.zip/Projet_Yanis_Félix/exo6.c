#include "Code.h"
#include "Extra.h"

int search_and_replace(char **str, HashMap *values) 
{
    if (!str || !*str || !values) return 0;

    char *input = *str;
    int replaced = 0;
    char *output = malloc(strlen(input) + 1);
    strcpy(output, input);

    for (int i = 0; i < TABLE_SIZE; i++) {
        HashEntry *entry = &values->table[i];
        if (!entry->key || entry->key == TOMBSTONE) continue;

        char *key = entry->key;
        int *value_ptr = (int*)entry->value;
        char value_str[32];
        snprintf(value_str, sizeof(value_str), "%d", *value_ptr);

        char *found = strstr(output, key);
        while (found) {
            replaced = 1;
            
            // Calcul des nouvelles tailles
            size_t key_len = strlen(key);
            size_t val_len = strlen(value_str);
            size_t new_len = strlen(output) - key_len + val_len + 1;
            
            // Allocation nouvelle chaîne
            char *new_str = malloc(new_len);
            
            // Copie des parties
            strncpy(new_str, output, found - output);
            new_str[found - output] = '\0';
            strcat(new_str, value_str);
            strcat(new_str, found + key_len);
            
            // Remplacement
            free(output);
            output = new_str;
            
            // Recherche suivante
            found = strstr(output, key);
        }
    }

    if (replaced) {
        free(*str);
        *str = output;
    } else {
        free(output);
    }

    return replaced;
}

int resolve_constants(ParserResult *result)
{
    // Remplace les variables par leur adresse dans le segment de données, et les étiquettes par leur adresse dans le segment de code.

    if(result==NULL|| result->code_instructions == NULL)
    {
        printf("EROR NULL dans resolve_constants\n");
        return 0;
    }
    Instruction **tab_code_intruction = result->code_instructions;
    int i;
    int réussi = 1; 
    for (i = 0; i < result->code_count; i++)
    {
        // Pour chaque instruciton dans code instruciton on applique  search_and_replace avec label et memory_location
        int resultat_operand1 = search_and_replace(&tab_code_intruction[i]->operand1, result->labels);
        int resultat_operand2 = search_and_replace(&tab_code_intruction[i]->operand2, result->memory_locations);
        
        if (resultat_operand1 == 0 || resultat_operand2 == 0) 
            réussi = 0;
        
    }
    if (réussi==1) 
    {
        printf("les changements bien été faits\n");
        return 1;
    } 
    else 
    {
        printf("tous les changements n'ont pas réussi\n");
        return 0;
    }
   
}

void allocate_code_segment(CPU *cpu, Instruction **code_instructions, int code_count)
{
    // Alloue et initialise le segment de code (CS).

    if (cpu == NULL || code_instructions==NULL || code_count <= 0) 
	{
        printf("Parametres invalides\n");
        return;
    }
    Segment *segment_courant = cpu->memory_handler->free_list;
    while(segment_courant)
    {
        if(segment_courant->size - segment_courant->start >= code_count)
        {
            if(create_segment(cpu->memory_handler, "CS", segment_courant->start, code_count)==1)
                printf("Segment CS cree !\n");
            
            else
                printf("Error dans allocate_code_segment : creat_segment en bizzard\n");

            break; 
        }
        segment_courant = segment_courant->next;
    }

    for (int i = 0; i < code_count; i++) 
    {
        // Pour chaque instruction dans code_instructuion je le met dans memory (segment de donne) en prenant soin de faire un copie pour eviter les double free avec memory et code_instruciton 
        Instruction *copie_instruciton = malloc(sizeof(Instruction));
        copie_instruciton->mnemonic = strdup(code_instructions[i]->mnemonic);
        copie_instruciton->operand1 = strdup(code_instructions[i]->operand1);
        copie_instruciton->operand2 = strdup(code_instructions[i]->operand2);
        store(cpu->memory_handler, "CS", i, copie_instruciton);
    }

    // initialiser lecregistre IP a 0 si c pas fait.
    int *ip = (int*)hashmap_get(cpu->context, "IP");
    if (ip) 
        *ip = 0;
    
}

int handle_instruction(CPU *cpu, Instruction *instr, void *src, void *dest)
{
    // Permet d’exécuter une instruction dans le CPU en fonction de son mnémonique.

    // Cas NULL
    if(cpu==NULL || instr == NULL)
    {
        printf("Error handle_instruction : argument invalide\n");
        return 0;
    }
    if((src==NULL||dest==NULL) && (strcmp(instr->mnemonic, "MOV")==0 ||strcmp(instr->mnemonic, "ADD")==0||strcmp(instr->mnemonic, "CMP")==0))
    {
        printf("Error handle_instruction : argument invalide MOV...\n");
        return 0;
    }
    
    // Recupere la taille de CS pour avoir le nb d'instruction
    Segment *segement_code  = hashmap_get(cpu->memory_handler->allocated, "CS");
    if(segement_code == NULL)
    {   
        printf("Eror handle_instruction : Veuillez creer le segment CS\n");
        return 0;
    }

    if(strcmp(instr->mnemonic, "MOV")==0)
    {
        // MOV dst, src : transfere la valeur de la source vers la destination.

        int *new_val = malloc(sizeof(int));
        *new_val = *(int*)src;
        if(hashmap_insert(cpu->context, dest, new_val)==0)
        {
            printf("EROR handle_instruction : MOV\n");
            return 0;
        } 
        return 1;
    }
    else if (strcmp(instr->mnemonic, "ADD")==0)
    {
         // Cas ADD dst, src : additionne les valeurs de la source et de la destination, puis stocke le r´esultat dans la destination.

        int *new_val = malloc(sizeof(int));//Cree un entier eviter les doubles free
        *new_val = *(int*)hashmap_get(cpu->context, dest) + *(int*)src;
        if(hashmap_insert(cpu->context, dest, new_val)==0)
        {
            printf("l'instruction %s %s %s na pas put etre effectuer\n", instr->mnemonic, instr->operand1, instr->operand2);
            return 0;
        }   
        return 1;
    }
    else if (strcmp(instr->mnemonic, "CMP")==0)
    {
        // Cas CMP dst, src : effectue une soustraction logique dst − src (sans modifier les operandes) et met a jour des drapeaux (ZF = 1 si et seulement si dst = src et SF = 1 si et seulement si dst < src).
    
        int val_dest = *(int*)hashmap_get(cpu->context, dest);
        int val_src = *(int*)src;

        if(val_dest == val_src)
        {
            int *new_val = malloc(sizeof(int));
            *new_val = 1;
            if(hashmap_insert(cpu->context,"ZF", new_val)==0)
            {
                printf("EROR handle_instruction : CMP-ZF\n");
            	return 0;
            }
            return 1;
        }
        else if(val_dest<val_src)
        {
            int *new_val = malloc(sizeof(int));
            *new_val = 1;
            if(hashmap_insert(cpu->context,"SF", new_val))
            {
                printf("EROR handle_instruction : CMP-SF\n");
                return 0;
            }
            return 1;
        }
        
    }
    else if (strcmp(instr->mnemonic, "JMP")==0)
    {
        // Cas JMP address : modifie le pointeur d’instruction IP pour changer le flux d’execution, c’est a-dire IP ←− address.

        int *new_val = malloc(sizeof(int));
        *new_val = atoi(src);

        if(hashmap_insert(cpu->context, "IP", new_val)==0)
        {
            printf("EROR handle_instruction : JMP\n");
            return 0;
        }
        return 1;
    }
    else if(strcmp(instr->mnemonic, "JZ")==0)
    {
        // Cas JZ address : moifie la prochaine instruction si ZF = 1 alors IP ←− address.

        int *ZF = (int*)hashmap_get(cpu->context,"ZF");
        if (ZF && *ZF == 1) 
        {
            int *new_val = malloc(sizeof(int));
            *new_val = atoi(src);
            if(hashmap_insert(cpu->context,"IP", new_val))
            {
                printf("EROR handle_instruction : JZ\n");
                return 0;
            }
            return 1;
        }
    }
    else if(strcmp(instr->mnemonic, "JNZ")==0)
    {
        // Cas JNZ address : moifie la prochaine instruction si ZF = 0 alors IP ←− address.

        int *ZF = (int*)hashmap_get(cpu->context,"ZF");
        if (ZF && *ZF == 0) 
        {
            int *new_val = malloc(sizeof(int));
            *new_val = atoi(src);
            if(hashmap_insert(cpu->context,"IP", new_val)==0)
            {
                printf("EROR handle_instruction : JNZ\n");
                return 0;
            }
            return 1;
        }
    }
    else if (strcmp(instr->mnemonic, "HALT")==0)
    {
        int *new_val = malloc(sizeof(int));
        *new_val = segement_code->start + segement_code->size;
        if(hashmap_insert(cpu->context,"IP", new_val))
        {
            printf("EROR handle_instruction : HALT\n");
            return 0;
        }
        return 1;
    }

    else if(strcmp(instr->mnemonic, "PUSH")==0)
    {
        // Cas PUSH 
        if(src==NULL)
        {
            int *val_ax = (int*)hashmap_get(cpu->context,"AX");
            if(val_ax)
            {
                int err = pushvalue(cpu,*val_ax);
                if(err==-1)
                {
                    printf("ERROR handle_instruction : PUSH AX\n");
                    return 0;
                }
                
            }    
            else
            {
                printf("ERROR handle_instruction : PUSH AX val_ax NULL\n");
                return 0;
            } 

        }
        else
            pushvalue(cpu, *(int*)src);
    }
    
    else if(strcmp(instr->mnemonic, "POP")==0)
    {
        // Cas POP
        if(dest == NULL)
        {
            int *val_ax = (int*)hashmap_get(cpu->context,"AX");
            if(val_ax)
            {
                int err = pop_value(cpu, val_ax);
                if(err==-1)
                {
                    printf("ERROR handle_instruction : POP AX\n");
                    return 0;
                }
                    
            }    
            else
            {
                printf("ERROR handle_instruction : POP AX val_ax NULL\n");
                return 0;
            } 
        }
        else
        {
            int *val_ax = (int*)hashmap_get(cpu->context,dest);
            pop_value(cpu, val_ax);
        }
            
    }

    else if(strcmp(instr->mnemonic, "ALLOC")==0)
    {
        // Cas POP
        if (alloc_es_segment(cpu)==0) 
            return 0;
        
        printf("ERROR handle_instruciton : ALLOC\n");
        return 1;
    }

    else if (strcmp(instr->mnemonic, "FREE") == 0) 
    {
        // Cas POP
        if (free_es_segment(cpu)==0) 
            return 0;
    
        return 1;
    }

    return 0;
}

int execute_instruction(CPU *cpu, Instruction *instr)
{
    // Résout les adresses des opérandes en fonction du type d’adressage, puis délègue l’exécution proprement dite à la fonction handle_instruction.
    if(cpu==NULL || instr == NULL)
    {
        printf("EROR execute_instruction : champ NULL\n");
        return 0;
    }
    void *src = NULL;
    void *dest = NULL;

    // Cas pour les memonics ADD, CMP, JNZ
    if(strcmp(instr->mnemonic, "MOV") == 0 || strcmp(instr->mnemonic, "ADD") == 0 || strcmp(instr->mnemonic, "CMP") == 0)
    {
        src = resolve_addressing(cpu, instr->operand2);
        dest = instr->operand1;
        if (src==NULL) 
        {
            printf("EROR execute_instruction : ");
            return 0;
        }
    }
    // Cas pour les memonics JMP, JZ, JNZ
    else if (strcmp(instr->mnemonic, "JMP") == 0 || strcmp(instr->mnemonic, "JZ") == 0 || strcmp(instr->mnemonic, "JNZ") == 0) 
    {
        src = resolve_addressing(cpu, instr->operand1);
        if (src==NULL) 
        {
            printf("EROR execute_instruction : ");
            return 0;
        }
    }
    // Cas pour PUSH et POP
    else if(strcmp(instr->mnemonic, "PUSH") == 0)
    {
        src = resolve_addressing(cpu, instr->operand1);
    }
    else if(strcmp(instr->mnemonic, "POP") == 0)
    {
        dest = instr->operand1;
    }
    else if(strcmp(instr->mnemonic, "ALLOC") == 0 || strcmp(instr->mnemonic, "FREE")==0)
    {}

    return handle_instruction(cpu, instr, src, dest);
}

Instruction* fetch_next_instruction(CPU *cpu) 
{
    // Récupère l’instruction à l’adresse pointée par le pointeur d’instruction (IP) dans un segment de code.
    if (!cpu) return NULL;

    Segment *segement_code  = hashmap_get(cpu->memory_handler->allocated, "CS");
    if(segement_code == NULL)
    {   
        printf("Eror handle_instruction : Veuillez creer le segment CS\n");
        return 0;
    }
    int *IP = (int*)hashmap_get(cpu->context, "IP");
    if(IP == NULL || *IP >  (segement_code->start+segement_code->size) - segement_code->start)
    {
        printf("ERROR fetch_next_instruction : Registre IPO absent ou limite ateint\n");
        if(IP==NULL)
            printf("IP NULL\n");
        if(*IP > segement_code->size - segement_code->start)
            printf("Ip %d > %d\n",*IP, (segement_code->start+segement_code->size) - segement_code->start);
        return NULL;
    }
    Instruction *next_instruction = load(cpu->memory_handler, "CS", *IP);
    
    (*IP)++;

    return next_instruction;
}

int run_program(CPU *cpu)
{
    if(cpu==NULL)
    {
        printf("Error run_program : cas NULL\n");
    }
    affiche_data_segment(cpu);
    affiche_registre(cpu);


    char c = '\n';

    while (c != 'q') 
    {
        printf("Entrez une valeur [Entree : continuer], [q : stop] : ");
    
        scanf("%c", &c);

        if (c == '\n') 
        {
            printf("Vous avez appuye sur Entree.\n");
        }
        else if (c == 'q') 
        {
            printf("Merci!\n");
            break;
        }
        else 
        {
            printf("Vous avez entré : %c\n", c);
            break;
        }
    
        Instruction *instr = fetch_next_instruction(cpu);
        if (!instr) 
        {
            printf("Erreur run_programme : Limite atteinte ou erreur bizarre\n");
            return 0;
        }
    
        printf("Operation : %s %s %s\n", instr->mnemonic, instr->operand1, instr->operand2);
        execute_instruction(cpu, instr);
        printf("CPU :\n");
        affiche_data_segment(cpu);
        printf("Registre :\n");
        affiche_registre(cpu);
    }
    return 1;
}