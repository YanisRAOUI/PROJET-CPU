#include "Cpu.h"

CPU *cpu_init(int memory_size)
{
	CPU* new_cpu= (CPU*)malloc(sizeof(CPU));
	if (new_cpu==NULL)
	{
		printf ("erreur d'alloc CPU\n");
		return NULL;
	}
	
	new_cpu->memory_handler= memory_init(memory_size);
	if(new_cpu->memory_handler==NULL)
	{
		printf("erreur d'alloc MemHand\n");
		free(new_cpu);
		return NULL;
	}
	
	new_cpu->context= hashmap_create();
	new_cpu->constant_pool = hashmap_create();
	if(new_cpu->context==NULL || new_cpu->constant_pool==NULL)
	{
		printf("erreur d'alloc HashMap\n");
		destroy_handler(new_cpu->memory_handler);
		free(new_cpu);
		return NULL;
	}
	
	int *val1= (int*)malloc(sizeof(int));
	int *val2= (int*)malloc(sizeof(int));
	int *val3= (int*)malloc(sizeof(int));
	int *val4= (int*)malloc(sizeof(int));
	int *val5= (int*)malloc(sizeof(int));
	int *val6= (int*)malloc(sizeof(int));
	int *val7= (int*)malloc(sizeof(int));
	int *val8= (int*)malloc(sizeof(int));
	
	if (val1==NULL || val2==NULL || val3==NULL || val4==NULL|| val5==NULL|| val6==NULL|| val7==NULL|| val8 == NULL)
	{
		printf("Erreur d'allocation des valeurs pour le registres\n");
		hashmap_destroy(new_cpu->context);
		destroy_handler(new_cpu->memory_handler);
        free(new_cpu);
        free(val1); 
        free(val2); 
        free(val3); 
        free(val4);
		free(val5);
		free(val6);
		free(val7);
		free(val8);
        return NULL;
    }
    
    *val1= 0;
    *val2= 0;
    *val3= 0;
    *val4= 0;
	*val5= 0;
    *val6= 0;
    *val7= 0;
	*val8 = -1;
	

	// Initialise AX
	int i= hashmap_insert(new_cpu->context, "AX", val1);
	if(i==0)
	{
		printf("ERROR cpu_init : AX\n");
		free(val1); free(val2); free(val3); free(val4);free(val5);free(val6);free(val7);free(val8);
		hashmap_destroy(new_cpu->context);
		destroy_handler(new_cpu->memory_handler);
		free(new_cpu);
		return NULL;
	} else 
	{
		printf("insertion AX réussie\n");
	}
	
	// Initialise BX
	i = hashmap_insert(new_cpu->context, "BX", val2);
	if( i==0)
	{
		printf("ERROR cpu_init : BX\n");
		free(val2); free(val3); free(val4);free(val5);free(val6);free(val7);free(val8);
		hashmap_destroy(new_cpu->context);
		destroy_handler(new_cpu->memory_handler);
		free(new_cpu);
		return NULL;
	} else 
	{
		printf("insertion BX réussie\n");
	}
	
	// Initialise CX
	i= hashmap_insert(new_cpu->context, "CX", val3);
	if(i==0)
	{
		printf("ERROR cpu_init : CX\n");
		free(val3); free(val4);free(val5);free(val6);free(val7);free(val8);
		hashmap_destroy(new_cpu->context);
		destroy_handler(new_cpu->memory_handler);
		free(new_cpu);
		return NULL;
	} else 
	{
		printf("insertion CX réussie\n");
	}
	
	// Initialise DX
	i = hashmap_insert(new_cpu->context, "DX", val4);
	if(i==0)
	{
		printf("ERROR cpu_init : DX\n");
		free(val4);free(val5);free(val6);free(val7);free(val8);
		hashmap_destroy(new_cpu->context);
		destroy_handler(new_cpu->memory_handler);
		free(new_cpu);
		return NULL;
	}
	else 
	{
		printf("insertion DX réussie\n");
	}
	
	// Initialise IP
	i = hashmap_insert(new_cpu->context, "IP", val5);
	if(i==0)
	{
		printf("ERROR cpu_init : IP\n");
		free(val5);free(val6);free(val7);free(val8);
		hashmap_destroy(new_cpu->context);
		destroy_handler(new_cpu->memory_handler);
		free(new_cpu);
		return NULL;
	}
	else 
	{
		printf("insertion IP réussie\n");
	}

	// Initialise ZF
	i = hashmap_insert(new_cpu->context, "ZF", val6);
	if(i==0)
	{
		printf("ERROR cpu_init : ZF\n");
		free(val6);free(val7);free(val8);
		hashmap_destroy(new_cpu->context);
		destroy_handler(new_cpu->memory_handler);
		free(new_cpu);
		return NULL;
	}
	else 
	{
		printf("insertion ZF réussie\n");
	}
	
	// Initialise SF
	i = hashmap_insert(new_cpu->context, "SF", val7);
	if(i==0)
	{
		printf("ERROR cpu_init : DX\n");
		free(val7);free(val8);
		hashmap_destroy(new_cpu->context);
		destroy_handler(new_cpu->memory_handler);
		free(new_cpu);
		return NULL;
	}
	else 
	{
		printf("insertion SF réussie\n");
	}

	// Initialise SS

	int SS_start = memory_size - 128;
	int SS_size = 128;

	if(create_segment(new_cpu->memory_handler, "SS", SS_start, SS_size)==0)
	{
		printf("ERROR cpu_init : SS\n");
		hashmap_destroy(new_cpu->context);
		destroy_handler(new_cpu->memory_handler);
		free(new_cpu);
		return NULL;
	}

	int *val_sp = malloc(sizeof(int));
	*val_sp = memory_size;
	i = hashmap_insert(new_cpu->context, "SP", val_sp);

	if(i==0)
	{
		printf("ERROR cpu_init : SP\n");
		hashmap_destroy(new_cpu->context);
		destroy_handler(new_cpu->memory_handler);
		free(new_cpu);
		return NULL;
	}
	else
	{
		printf("insertion SP réussie\n");
	}

	// Initialise BP

	int *val_bp = malloc(sizeof(int));
	*val_bp = memory_size;
	i = hashmap_insert(new_cpu->context, "BP", val_bp);
	if(i==0)
	{
		printf("ERROR cpu_init : BP\n");
		hashmap_destroy(new_cpu->context);
		destroy_handler(new_cpu->memory_handler);
		free(new_cpu);
		return NULL;
	}
	else 
	{
		printf("insertion BP réussie\n");
	}
	
	//Initialise ES 
	i = hashmap_insert(new_cpu->context, "ES", val8);
	if(i==0)
	{
		printf("ERROR cpu_init : ES\n");
		free(val8);
		hashmap_destroy(new_cpu->context);
		destroy_handler(new_cpu->memory_handler);
		free(new_cpu);
		return NULL;
	}
	else 
	{
		printf("insertion ES réussie\n");
	}

	return new_cpu;
}

void cpu_destroy(CPU *cpu) 
{
    if (!cpu) 
		return;

    if (cpu->context) 
		hashmap_destroy(cpu->context);
    

    if (cpu->memory_handler) 
		destroy_handler(cpu->memory_handler);
	
	if(cpu->constant_pool)
		hashmap_destroy(cpu->constant_pool);
    

    free(cpu);
}

void *store(MemoryHandler *handler, const char *segment_name, int pos, void *data)
{
	if (handler == NULL || segment_name == NULL || data == NULL) 
        return NULL;
    
    
	Segment *seg= hashmap_get(handler->allocated, segment_name);
	if (seg==NULL || pos >= seg->size)
	{
		printf("segment non trouvé ou place insufisant\n");
	}
	else
	{	
		handler->memory[seg->start + pos]=data;
		return data;
	}
	return NULL;
}

void *load(MemoryHandler *handler, const char *segment_name, int pos)
{
	if (handler == NULL || segment_name == NULL)
	{
		printf("un des element est NULL, on peut pas récupérer la donnée\n");
        return NULL;
    }

	Segment *seg= hashmap_get(handler->allocated, segment_name);
	if (seg==NULL|| pos >= seg->size)
	{
		printf("ERROR load segment pas trouvé\n");
		return NULL;
	}

	return handler->memory[seg->start + pos];

}

void allocate_variables(CPU *cpu, Instruction** data_instructions,int data_count)
{

	if (cpu == NULL || data_instructions==NULL || data_count <= 0) 
	{
        printf("Parametres invalides\n");
        return;
    }

	// Calcul de l’espace n ́ecessaire au stockage des variables
	int i;
	int size = 0;
	for(i=0; i<data_count; i++)
	{
		char *s = data_instructions[i]->operand2;
		if(s==NULL || strcmp(s,"")==0){}
		else
		{
			// s contient un , : emplacement > 1 est necessaire
			if(strchr(s, ','))
			{
				char *s_copy = strdup(s);
				if (s_copy==NULL){}
				else
				{
					char *l = strtok(s_copy, ",");
					while (l) 
					{
						size++;
						l = strtok(NULL, ",");
					}

		
				}
				free(s_copy); 
			} 
			else
				size++;
		}
	}

	// D'eclaration d’un segment nommé DS dans le MemoryHandler.
	create_segment(cpu->memory_handler,"DS" , 0, size);

	//Remplissage du segment de données avec les valeurs d ́eclaréees dans la section .DATA du code.
	int position = 0;
	for(i = 0; i < data_count; i++) 
	{
		char *s = data_instructions[i]->operand2;
		if (s == NULL || strcmp(s, "") == 0) {}
	
		if (strchr(s, ',')) 
		{
			// Cas ou il y a plusieurs valeurs declarer dans la section 
			char *tmp = strdup(s);
			if (tmp == NULL){}
			else 
			{
				char *l = strtok(tmp, ","); 
				while (l) 
				{
					//Insere chaque valeurs dans memory_handler
					int *x = malloc(sizeof(int)); 
					if (x) 
					{
						*x = atoi(l); 
						store(cpu->memory_handler, "DS", position, x); 
						position++; 
					}
					l = strtok(NULL, ","); 
				}
				free(tmp); 
			}
		} 
		else 
		{
			// Il y a q'une valeur
			int *x = malloc(sizeof(int));
			if (x) 
			{
				*x = atoi(s); 
				store(cpu->memory_handler, "DS", position, x); 
				position++;
			}
		}
	}
	
}

void affiche_data_segment(CPU  *cpu)
{
	Segment* ds= hashmap_get(cpu->memory_handler->allocated, "DS");
	if (ds==NULL)
	{
		printf("pas de segment ds trouvé\n");
		return;
	}
	for(int i=0; i<ds->size; i++)
	{
			int*a= load(cpu->memory_handler, "DS", i);
			if (a!= NULL)
			{
				printf("%d : %d\n", i, *a);
			}
	}
}		
	
	
