#ifndef HASHMAP_H
#define HASHMAP_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define TOMBSTONE (( void *) -1)
#define  TABLE_SIZE 128

typedef struct hashentry
{
	char * key ;
	void * value ;
} HashEntry ;


typedef struct hashmap 
{
	int size ;
	HashEntry *table ;
} HashMap ;


unsigned long simple_hash(const char *str);
// HashMap *hashmap_create(); fonction en plus, on s'en est pas servi pour l'instant
int hashmap_insert(HashMap *map, const char *key, void *value);
HashMap *hashmap_create();
int hashmap_remove(HashMap *map, const char *key);
void *hashmap_get(HashMap *map, const char *key);
int hashmap_remove(HashMap *map, const char *key);
void hashmap_destroy(HashMap *map);
void afficher_hashmap(HashMap *map);

#endif 


