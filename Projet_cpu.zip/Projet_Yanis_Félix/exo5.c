#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Adressage.h"
#include "Extra.h"
#include <regex.h>


char *pattern_Adressage_immediat = "^[0-9]+$"; // MOV AX,42
char *pattern_Adressage_par_registre = "^(AX|BX|CX|DX)$";// MOV AX,BX
char *pattern_Adressage_direct = "^\\[[0-9]+\\]$";// MOV AX,[5]
char *pattern_Adressage_indirect_par_registre = "^\\[(AX|BX|CX|DX)\\]$";// MOV BX,[AX]

int matches (const char *pattern, const char *string)
{
    regex_t regex;
    int val = regcomp (&regex, pattern, REG_EXTENDED);
    if (val)
    {
        fprintf(stderr, "Regex compilation failed for pattern: %s\n", pattern);
        return 0;
    }
    val= regexec(&regex, string, 0, NULL, 0);
    regfree(&regex);
    return val == 0;
}

void *immediate_addressing(CPU *cpu, const char *operand)
{
    // Donne directement la data a utilise qui est operand Ex : MOV AX,42 data = 42 --> met 42 dans AX

    if(matches(pattern_Adressage_immediat, operand))
    {
        void *data = hashmap_get(cpu->constant_pool, operand);
        if(data)
        {
            printf("Immediate_addressing : valeurs deja stocke dans constant_pool\n");
            return data;
        }
        printf("On stock la valeur dans constant_pool\n");
        int *val = malloc(sizeof(int));
        *val = atoi(operand);
        hashmap_insert(cpu->constant_pool, operand, val);
        return val;
    }
    printf("EROR immediate_addressing : l'operand ne respecte pas la synthaxe\n");
    return NULL;
}

void *register_addressing(CPU *cpu, const char *operand)
{
    // Va chercher la data contenue dans le registre Ex : BX = 42 --> MOV AX,BX met 42 dans AX
    if(matches(pattern_Adressage_par_registre, operand))
    {
        if(hashmap_get(cpu->context, operand))
            return hashmap_get(cpu->context, operand);
        printf("Ce registre est vide\n");
        return NULL;
    }
    printf("EROR register_addressing : l'operand ne respecte pas la synthaxe\n");
    return NULL;
}

void *memory_direct_addressing(CPU *cpu, const char *operand)
{
    // Va chercher la data via l'adresse (ici la position dans memory) donnee par operand Ex: memory[5] = 42 -->MOV AX,[5] met 42 dans AX
    if(matches(pattern_Adressage_direct, operand))
    {
        //extraire l’adresse numérique
        char pos [100];
        int i = 1;
        int j = 0;
        while (operand[i]!=']' && operand[i]!='\0')
        {
            pos[j] = operand[i];
            i++; 
            j++;
        }
        pos[j]='\0';
        
        int position = atoi(pos);
        void *val = load(cpu->memory_handler, "DS", position);
        if (position < 0 || position >= cpu->memory_handler->total_size ||val == NULL) 
        {
            printf("Position incorect\n");
            return NULL;
        }
        return val;
    }
    
    printf("EROR memory_direct_addressing : l'operand ne respecte pas la synthaxe\n");
    return NULL;
}

void *register_indirect_addressing(CPU *cpu, const char *operand)
{
    // Va chercher la data via l'adresse contenue dans le registre donne par operand Ex : AX = 0x001(42) --> MOV BX,[AX] met 42 dans BX
    if(matches(pattern_Adressage_indirect_par_registre, operand))
    {
        // extraire le nom du registre 
        char registre[3];
        registre[0] = operand[1];
        registre[1] = operand[2];
        registre[2] = '\0';
        // cherche l'adresse contenue dans le registre
        void *adresse = hashmap_get(cpu->context, registre);
        if(adresse)
        {
            int position = *(int*)adresse; 
            void *val = load(cpu->memory_handler, "DS", position);
            if (position >= cpu->memory_handler->total_size ||val == NULL) 
            {
                printf("Position incorect\n");
                return NULL;
            }
            return val;
        }
        printf("Ce registre ne contient pas d'adresse\n");
        return NULL;
    }
    printf("EROR register_indirect_addressing : l'operand ne respecte pas la synthaxe\n");
    return NULL;
}

void handle_MOV(CPU* cpu, void* src, void* dest) 
{
    if(matches(pattern_Adressage_immediat, src))
    {
        void *val = immediate_addressing(cpu,src);
        if (val) 
        {
            /*Copie la valeur evite que le registre pointe vers la meme value
            qui serait dans le registre et aussi dans constantpool d'ou l'erreur lors du free 
            parcque quand on detrruit le CPU si je detruit la value qui est dans constantpool alors la value dans ce registre sera NULL et on va free un truc NULL error(vis versa).*/ 
            int *new_val = malloc(sizeof(int));
            *new_val = *(int*)val;
            hashmap_insert(cpu->context, dest, new_val);
        }
        else
            printf("EROR handle_MOV : lors de l'echange de registre\n");
    }
    else if (matches(pattern_Adressage_par_registre, src))
    {
        void *val = register_addressing(cpu,src);
        if (val) 
        {
            // Pareil mais ici on evite que les deux registre pointe vers la meme value
            
            int *new_val = malloc(sizeof(int));
            *new_val = *(int*)val;
            hashmap_insert(cpu->context, dest, new_val);
        }
        else
            printf("EROR handle_MOV : lors de l'echange de registre\n");
    }
    else if(matches(pattern_Adressage_direct, src))
    {
        void *val = memory_direct_addressing(cpu,src);
        if (val) 
        {
            // Pareil 
            int *new_val = malloc(sizeof(int));
            *new_val = *(int*)val;
            hashmap_insert(cpu->context, dest, new_val);
        }
        else
            printf("EROR handle_MOV : lors de l'echange de registre\n");
    }
    else if(matches(pattern_Adressage_indirect_par_registre, src))
    {
        void *val = register_indirect_addressing(cpu,src);
        if (val) 
        {
            // Pareil 
            int *new_val = malloc(sizeof(int));
            *new_val = *(int*)val;
            hashmap_insert(cpu->context, dest, new_val);
        }
        else
            printf("EROR handle_MOV : lors de l'echange de registre\n");
    }
    else
    {
        printf("ERROR handle_MOV : aucun adressage possible\n");
        return;
    }
    
}

CPU *setup_test_environment() 
{
    // Initialiser le CPU
    CPU *cpu = cpu_init(1024);
    if (!cpu) 
    {
        printf("Erreur : initialisation du CPU échouée\n");
        return NULL;
    }

    // Initialiser les registres avec des valeurs spécifiques
    int *ax = (int *) hashmap_get(cpu->context, "AX");
    int *bx = (int *) hashmap_get(cpu->context, "BX");
    int *cx = (int *) hashmap_get(cpu->context, "CX");
    int *dx = (int *) hashmap_get(cpu->context, "DX");

    *ax = 3;
    *bx = 6;
    *cx = 100;
    *dx = 0;

    // Créer et initialiser le segment de données "DS" si non existant
    if (!hashmap_get(cpu->memory_handler->allocated, "DS")) 
    {
        create_segment(cpu->memory_handler, "DS", 0, 20);

        // Initialiser le segment avec des valeurs de test
        for (int i = 0; i < 10; i++) {
            int *value = (int *) malloc(sizeof(int));
            *value = i * 10 + 5;  // Valeurs : 5, 15, 25, 35, ...
            store(cpu->memory_handler, "DS", i, value);
        }
    }

    printf("Test environment initialized.\n");
    return cpu;
}

void affiche_registre(CPU *cpu)
{
    if(cpu==NULL || cpu->context==NULL ) 
    {
        printf("Registre vide\n");
        return;
    }
    int  i = 0;
    while (i<TABLE_SIZE)
    {
        HashEntry *entry = &cpu->context->table[i]; 
        if(entry->key!=NULL && entry->key!=TOMBSTONE)
        {
            printf("%s : %d\n", entry->key, *(int*)entry->value);
        }
        i++;
    }
    
}

void *resolve_addressing(CPU *cpu, const char *operand) 
{
    void *val = immediate_addressing(cpu, operand);
    if (val != NULL)
        return val;

    val = register_addressing(cpu, operand);
    if (val != NULL)
        return val;

    val = memory_direct_addressing(cpu, operand);
    if (val != NULL)
        return val;

    val = register_indirect_addressing(cpu, operand);
    if (val != NULL)
        return val;

    val = segment_override_addressing(cpu, operand);
    if (val != NULL)
        return val;

    printf("operand bizarre dans resolve_adressing\n");
    return NULL;
}
 
