#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "HashMap.h"
#include "Segment.h"
#include "Parser.h"
#include "Cpu.h"
#include "Adressage.h"
#include "Code.h"
#include "Stack.h"
#include "Extra.h"

int main() 
{
	printf("\n");
	printf("\n");
	printf("\n");
	printf("\n");
	printf("\n");
 //---------------------------------------------------------TEST EXO 1-------------------------------------------------------
	printf("---------------TEST EXO1--------------------------\n");
    printf("Création de la table:\n");
    HashMap *map = hashmap_create();
    if (map == NULL) {
        printf("Erreur création table de hachage\n");
        return 1;
    }
    printf("Table créée avec succès\n\n");

    // Allocation dynamique des valeurs (adapté à tout type)
    int *value1 = malloc(sizeof(int));
    int *value2 = malloc(sizeof(int));
    if (!value1 || !value2) {
        printf("Erreur d'allocation mémoire\n");
        free(value1);
        free(value2);
        hashmap_destroy(map);
        return 1;
    }
    *value1 = 42;
    *value2 = 73;

    // Insertions
    printf("Insertion de 'test1':\n");
    if (!hashmap_insert(map, "test1", value1)) {
        printf("Échec insertion - libération de value1\n");
        free(value1);
    }

    printf("\nInsertion de 'test2':\n");
    if (!hashmap_insert(map, "test2", value2)) {
        printf("Échec insertion - libération de value2\n");
        free(value2);
    }

    afficher_hashmap(map);

    // Insertion avec clé existante (remplacement)
    printf("\nInsertion de 'test1' avec nouvelle valeur:\n");
    int *new_value = malloc(sizeof(int));
    if (!new_value) {
        printf("Erreur allocation nouvelle valeur\n");
    } else {
        *new_value = 100;
        if (!hashmap_insert(map, "test1", new_value)) {
            printf("Échec insertion - libération new_value\n");
            free(new_value);
        }
    }

    afficher_hashmap(map);

    // Recherches
    printf("\nRecherche de 'test1':\n");
    int *found = hashmap_get(map, "test1");
    if (found) printf("Valeur trouvée: %d\n", *found);
    else printf("Clé non trouvée\n");

    printf("\nRecherche de 'test3' (inexistante):\n");
    found = hashmap_get(map, "test3");
    if (found) printf("Valeur trouvée: %d\n", *found);
    else printf("Clé non trouvée\n");
    
    // Suppressions
    printf("\nSuppression de 'test1':\n");
    if (hashmap_remove(map, "test1")) {
        printf("Suppression réussie\n");
    } else {
        printf("Échec suppression\n");
    }

    // Affichage final
    printf("\nContenu final de la table:\n");
    afficher_hashmap(map);

    // Nettoyage (libère toutes les clés ET valeurs)
    hashmap_destroy(map);
    printf("\nTable détruite - mémoire libérée\n");

    printf("\n");
 	printf("\n");
 	printf("\n");
 	printf("\n");
 	printf("\n");
	
     //---------------------------------------------------------TEST EXO 2-------------------------------------------------------
   
	printf("---------------TEST EXO2--------------------------\n");
    
    MemoryHandler *new = memory_init(100);
	if(new)
	{
        printf("création réussie\n");
        afficher_handler(new);
        printf("\n");

        printf("Test de creat_segment\n");
        create_segment(new, "0", 0, 10);
        afficher_segment(new->free_list);
        create_segment(new, "1", 20, 10);
        afficher_segment(new->free_list);
        create_segment(new, "2", 80, 10);
        afficher_segment(new->free_list);
        create_segment(new, "3", 90, 10);
        afficher_segment(new->free_list);
        create_segment(new, "4", 0, 100);
        afficher_segment(new->free_list);
        printf("\n");

        printf("Test de remove_segment\n");
        printf("Avant\n");
        
        afficher_segment(new->free_list);

        printf("Après\n");

        remove_segment(new,"3");
        afficher_segment(new->free_list);

        remove_segment(new,"2");
        afficher_segment(new->free_list);

        remove_segment(new,"1");
        afficher_segment(new->free_list);

        remove_segment(new,"0");
        afficher_segment(new->free_list);

        destroy_handler(new);

    }	
	else
		printf("création échouée\n");
   
    printf("\n");
	printf("\n");
	printf("\n");
	printf("\n");
	printf("\n");
    //---------------------------------------------------------TEST EXO 3-------------------------------------------------------
   
    printf("---------------TEST EXO3--------------------------\n");
    
    ParserResult *new_parse = parse("programme.txt");
    affiche_ParserResult(new_parse);
    printf("\n");

    resolve_constants(new_parse);
    affiche_ParserResult(new_parse);
    printf("\n");
	printf("\n");
	printf("\n");
	printf("\n");
	printf("\n");
    //---------------------------------------------------------TEST EXO 4-------------------------------------------------------
	printf("---------------TEST EXO4--------------------------\n");
	
	if(new_parse)
	{
		CPU *new_cpu = cpu_init(500);
		if(new_cpu)
        { 
            allocate_variables(new_cpu, new_parse->data_instructions,new_parse->data_count);
            affiche_data_segment(new_cpu);
            affiche_registre(new_cpu);
            free_parser_result(new_parse); 
            cpu_destroy(new_cpu); 	
        }
        else
        {
            printf("ERROR main Exo4: Cpu invalide verifiez\n");
            return 0;
        }
       
	}
	else
	{
		free_parser_result(new_parse); 
	}
	printf("\n");
	printf("\n");
	printf("\n");
	printf("\n");
	printf("\n");
	printf("\n");
    //---------------------------------------------------------TEST EXO 5-------------------------------------------------------
    printf("---------------TEST EXO5--------------------------\n");
    CPU *new_cpu = setup_test_environment();
    printf("---------------Avant---------------\n");

    printf("Registre\n");
    affiche_registre(new_cpu);

    printf("Segemnts de donnee\n");
    affiche_data_segment(new_cpu);

    printf("---------------Apres---------------\n");

    printf("Cas MOV AX,42\n");
    handle_MOV(new_cpu, "42", "AX");
    affiche_registre(new_cpu);

    printf("Cas MOV AX,BX\n");
    handle_MOV(new_cpu, "BX", "AX");
    affiche_registre(new_cpu);

    printf("Cas MOV AX,[3]\n");
    handle_MOV(new_cpu, "[3]", "AX");
    affiche_registre(new_cpu);

    printf("Cas MOV AX,[BX]\n");
    handle_MOV(new_cpu, "[BX]", "AX");
    affiche_registre(new_cpu);

    
    cpu_destroy(new_cpu);
    printf("\n");
    printf("\n");
    printf("\n");
    printf("\n");
    printf("\n");

 //---------------------------------------------------------TEST EXO 6-------------------------------------------------------

    printf("---------------TEST EXO6, 7 et 8--------------------------\n");
    // les fonctions des exo 6 7 8 sont tester via le fichier des instuctions programme.txt
    
    ParserResult *new_parse_exo6 = parse("programme.txt");
    affiche_ParserResult(new_parse_exo6);
    printf("\n");

	if(new_parse_exo6)
	{
		CPU *new_cpu_exo6 = cpu_init(500);
	    if(new_cpu_exo6)
        {
            affiche_registre(new_cpu_exo6);
            resolve_constants(new_parse_exo6);
            affiche_ParserResult(new_parse_exo6);

            allocate_variables(new_cpu_exo6, new_parse_exo6->data_instructions,new_parse_exo6->data_count);
            allocate_code_segment(new_cpu_exo6, new_parse_exo6->code_instructions, new_parse_exo6->code_count);

            afficher_handler(new_cpu_exo6->memory_handler);

            run_program(new_cpu_exo6);

            free_parser_result(new_parse_exo6); 
            cpu_destroy(new_cpu_exo6); 
        }
        else
        {
            printf("ERROR main Exo6: Cpu invalide verifiez\n");
            return 0;
        }
        
	}
	else
	{
		free_parser_result(new_parse_exo6); 
	}	
	printf("\n");
	printf("\n");
	printf("\n");
	printf("\n");
	printf("\n");
	printf("-------------------FIN DES TESTS-------------------------\n");
    return 0;
}
