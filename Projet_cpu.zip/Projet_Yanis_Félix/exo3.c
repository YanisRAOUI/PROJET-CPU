#include "Parser.h"

char *trim(char *str) 
{
    while (*str == ' ' || *str == '\t' || *str == '\n' || *str == '\r') 
    {
        str++;
    }

    char *end = str + strlen(str) - 1;
    while (end > str && (*end == ' ' || *end == '\t' || *end == '\n' || *end == '\r')) 
    {
        *end = '\0';
        end--;
    }

    return str;
}

void free_instruction(Instruction *instruction) 
{
    if (instruction == NULL) 
        return;

    if (instruction->mnemonic) 
        free(instruction->mnemonic);

    if (instruction->operand1) 
        free(instruction->operand1);

    if (instruction->operand2) 
        free(instruction->operand2);
    
    free(instruction);
}

Instruction *parse_data_instruction(const char *line, HashMap *memory_locations)
{
    static int count=0;

    Instruction* new_instruction= malloc(sizeof(Instruction));
    if (new_instruction==NULL) 
        return NULL;
    new_instruction->mnemonic = NULL;
    new_instruction->operand1 = NULL;
    new_instruction->operand2 = NULL;

    char* ligne= strdup(line);
    if (!ligne) 
    {
        free(new_instruction);
        return NULL;
    }

    // Découper la ligne 
    char* l= strtok(ligne, " ");
    if (l)
        new_instruction->mnemonic= strdup(l);

    l=strtok(NULL, " ");
    if (l)
        new_instruction->operand1 = strdup(l);

    l= strtok(NULL, "\n");
    if (l)
        new_instruction->operand2= strdup(l);

    if (new_instruction->mnemonic) 
    {
        int *tmp = malloc(sizeof(int));
        *tmp = count;
        hashmap_insert(memory_locations, new_instruction->mnemonic, tmp);
    }

    // si il existe un "," dans la l
    if(strchr(l, ','))
    {
        char *tmp = strdup(new_instruction->operand2);
        l = strtok(tmp, ",");
        while (l) 
        {
            count++;
            l = strtok(NULL, ",");
        }
        free(tmp); 
    } 
    else
        count++;

    free(ligne);
    return new_instruction;
}

Instruction *parse_code_instruction(const char *line, HashMap*labels, int code_count) 
{
    Instruction* new_instruction = malloc(sizeof(Instruction)); 
    if (new_instruction == NULL) 
        return NULL;
    new_instruction->mnemonic = NULL;
    new_instruction->operand1 = NULL;
    new_instruction->operand2 = NULL;

    char* ligne = strdup(line);     
    if (!ligne) 
    {
        free(new_instruction);
        return NULL;
    }

    char *l = NULL;
    int existe_label=0;
    if(strchr(ligne, ':')) 
    {
        l = strtok(ligne, ":");
        existe_label = 1;
        //On stock la valeurs de count dans une nouvelle adressse memoire pour evite que le chamsp value soit liee a l'attribut count de la fonciton
        int *tmp = malloc(sizeof(int));
        *tmp = code_count;

        if (hashmap_insert(labels, trim(l), tmp)==0) 
        {
            printf("ya error dans insert labels\n");
            free(ligne);
            free_instruction(new_instruction);
            return NULL;
        }
    }
    
    if(existe_label==1)
        l = strtok(NULL, " ");
    else
        l = strtok(ligne, " ");
    
    if(l)
        new_instruction->mnemonic = strdup(trim(l));
    else
    {
        new_instruction->mnemonic = strdup("");
        new_instruction->operand1 = strdup("");
        new_instruction->operand2 = strdup("");
        free(ligne);
        return new_instruction;
    }
        
    l = strtok(NULL, ",");
    if(l)
        new_instruction->operand1 = strdup(trim(l));
    else
    {
        new_instruction->operand1 = strdup("");
        new_instruction->operand2 = strdup("");
        free(ligne);
        return new_instruction;
    }
    
    l = strtok(NULL, " ");
    if (l) 
        new_instruction->operand2 = strdup(trim(l));
    else 
        new_instruction->operand2 = strdup("");

    free(ligne);
    return new_instruction;
}

ParserResult *parse(const char *filename) 
{
    FILE *f = fopen(filename, "r");
    if (!f) 
    {
        printf("Erreur d'ouverture du fichier");
        return NULL;
    }

    ParserResult *new_p = malloc(sizeof(ParserResult));
    if (!new_p) 
    {
        fclose(f);
        return NULL;
    }
        

    new_p->data_instructions = NULL;
    new_p->code_instructions = NULL;
    new_p->data_count = 0;
    new_p->code_count = 0;
    new_p->labels = hashmap_create();
    new_p->memory_locations = hashmap_create();



    if (!new_p->labels || !new_p->memory_locations) 
    {
        free_parser_result(new_p);
        fclose(f);
        return NULL;
    }

    char buffer[250];
    int data_taille = 0;
    int code_taille = 0;

    //Phase 1 touver la taille de data_instruction et code_instruction
    if(fgets(buffer, sizeof(buffer), f) && strcmp(buffer, ".DATA\n") == 0)
    {
        while (fgets(buffer, sizeof(buffer), f) && strcmp(buffer, ".CODE\n") != 0) 
        {
            if (strcmp(buffer, ".DATA\n") != 0) 
                data_taille ++;
        }
    }
    else
    {	
    	printf("%d\n", strcmp(buffer, ".DATA\n") == 0);
    	printf("%s\n",buffer);
        printf("ERROR parse : DATA\n");
        free_parser_result(new_p);
        fclose(f);
        return NULL;
    }
    if(strcmp(buffer, ".CODE\n") == 0)
    {
        while (fgets(buffer, sizeof(buffer), f)) 
        {
            code_taille ++;
        }
    }
    else
    {
        printf("ERROR parse : CODE\n");
        free_parser_result(new_p);
        fclose(f);
        return NULL;
    }

   

    new_p->data_instructions = calloc(data_taille, sizeof(Instruction*));
    new_p->code_instructions = calloc(code_taille, sizeof(Instruction*));
    
    if (!new_p->data_instructions || !new_p->code_instructions) 
    {
        free_parser_result(new_p);
        fclose(f);
        return NULL;
    }
    
    // Phase 2 pour rempmlire data_instruction et code_instruction

    rewind(f); //Remet f a la premier ligne du fichier
    int i = 0;
    fgets(buffer, sizeof(buffer), f); // Suprimme .DATA
    while (fgets(buffer, sizeof(buffer), f) && strcmp(buffer, ".CODE\n") != 0) 
    {
        buffer[strcspn(buffer, "\n")] = '\0';
        new_p->data_instructions[i] = parse_data_instruction(buffer, new_p->memory_locations);
        i++;
    }

    i = 0;
    while (fgets(buffer, sizeof(buffer), f)) 
    {
        buffer[strcspn(buffer, "\n")] = '\0';
        new_p->code_instructions[i] = parse_code_instruction(buffer, new_p->labels, i);
        i++;
    }


    new_p->data_count = data_taille;
    new_p->code_count = code_taille;
    fclose(f);
    return new_p;
}

void free_parser_result(ParserResult *presult) 
{
    if (!presult) 
        return;

    // Libération DATA
    for (int i = 0; i < presult->data_count; i++) 
    {
        free_instruction(presult->data_instructions[i]);
    }
    free(presult->data_instructions);

    // Libération CODE
    for (int i = 0; i < presult->code_count; i++) 
    {
        free_instruction(presult->code_instructions[i]);
    }
    free(presult->code_instructions);

    // Libération HashMaps
    hashmap_destroy(presult->memory_locations);
    hashmap_destroy(presult->labels);

    free(presult);
}

void affiche_ParserResult(ParserResult *presult)
{
    if(!presult)
    return;
    int i = 0;
    while (i < presult->data_count)
    {
        if(presult->data_instructions[i])
        {
            char *memonic = presult->data_instructions[i]->mnemonic;
            char *operand1 = presult->data_instructions[i]->operand1;
            char *operand2 = presult->data_instructions[i]->operand2;

            if (i == presult->data_count / 2)
                printf("data_instructions : |  \"%s\"  \"%s\"  \"%s\" |\n", memonic, operand1, operand2);
            else
                printf("                    |  \"%s\"  \"%s\"  \"%s\" |\n", memonic, operand1, operand2);
    
        }
        i++; 
        
    }

    printf("Memory locations\n");
    afficher_hashmap(presult->memory_locations);

    i = 0;
    while (i < presult->code_count)
    {
        if(presult->code_instructions[i])
        {

            char *memonic = presult->code_instructions[i]->mnemonic;
            char *operand1 = presult->code_instructions[i]->operand1;
            char *operand2 = presult->code_instructions[i]->operand2;
            
            if (i == presult->code_count / 2)
                printf("code_instructions : |  \"%s\"  \"%s\"  \"%s\" |\n", memonic, operand1, operand2);
            else
                printf("                    |  \"%s\"  \"%s\"  \"%s\" |\n", memonic, operand1, operand2);
            
        }
        i++; 
    }

    printf("Labels\n");
    afficher_hashmap(presult->labels);
}
