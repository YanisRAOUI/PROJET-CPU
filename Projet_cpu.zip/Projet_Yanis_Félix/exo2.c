#include "Segment.h"
#include "Parser.h"

void afficher_segment(Segment *l)
{
    // Affiche les segments
    if (l==NULL) return; // Cas NULL
    
    Segment *tmp = l;
    while (tmp->next) 
	{
        if (tmp) 
			printf("%d----%d-", tmp->start, tmp->start + tmp->size);
        tmp = tmp->next;
    }
    if (tmp) 
		printf("%d----%d\n", tmp->start, tmp->start + tmp->size);
}

void afficher_handler(MemoryHandler *handler)
{
    // Affiche handler
	printf("taille totale = %d\n",handler->total_size);
	afficher_segment(handler->free_list);
}

MemoryHandler *memory_init(int size)
{
    // Alloue un Memoryhandler et ses champs
    
    MemoryHandler *new = (MemoryHandler *)malloc(sizeof(MemoryHandler));
    if (!new)
    {
        printf("erreur d'allocation memoryhandler\n");
        return NULL;
    }

    // Alloue le champs memory
    new->memory = calloc(size, sizeof(void *));
    if (!new->memory)
    {
        free(new);
        printf("erreur d'allocation memory\n");
        return NULL;
    }

    // Alloue le champs free_list
    new->free_list = (Segment *)malloc(sizeof(Segment));
    if (!new->free_list)
    {
        free(new->memory);
        free(new);
        printf("erreur d'allocation segment\n");
        return NULL;
    }

    // Alloue le champs allocated
    new->allocated = hashmap_create();  // Utilise hashmapcreate sinon tu oublie d'initialiser la taille du tableau et les champs a NULL;

    if (!new->allocated)
    {
        free(new->free_list);
        free(new->memory);
        free(new);
        printf("erreur d'allocation hashmap\n");
        return NULL;
    }

    // Initialise ses champs

    new->total_size = size;
    new->free_list->start = 0;
    new->free_list->size = size;
    new->free_list->next = NULL;

    return new;
}

Segment* find_free_segment(MemoryHandler* handler, int start, int size, Segment **prev)
{
    // Renvoie une place libre dans la memoire 

	Segment *segment= handler->free_list;
	while (segment)
	{
        // Parcours les segment (memoire libre) 
		int s= (segment->start) + (segment->size);
		if(segment->start <= start && s>=start+size)
		{
            // Segment libre trouve 
			return segment; 
		}
		*prev = segment;
		segment = segment->next;
	}
	return NULL;
}

int create_segment(MemoryHandler *handler, const char *name, int start, int size)
{
    //Cree un segment en fonction de la memoire libre

    Segment *prev = NULL;
    Segment *seg_libre = find_free_segment(handler, start, size, &prev);

    if (!seg_libre) 
    {
        printf("Pas de place disponible\n");
        return 0;
    }
	else
	{
        //Creer le segment 

    	Segment *new_seg = (Segment*)malloc(sizeof(Segment));
    	if (!new_seg) return 0; // Erreur d'allocation 

        // Initialise ses champs
    	new_seg->start = start;
    	new_seg->size = size;
    	new_seg->next = NULL;

        // Insere dans le tableau de hashage
    	int h = hashmap_insert(handler->allocated, name, new_seg);
    	if (h==0)
		{
			free(new_seg);
			return 0;
		}
		
        // Cas ou le segment cree a la même taille que la segment libre trouver (feat parfaitement)
    	if (seg_libre->start == start && (seg_libre->start + seg_libre->size == start+size)) 
    	{
        	if (prev==NULL)
                //Cas ou il faut supprimer la tête
                handler->free_list = seg_libre->next;
        	else
                prev->next = seg_libre->next;

        	free(seg_libre);
            return 1;
    	}
        
        //Cas ou le segment creer a le même start que le segment libre (debut) : on diminue la taille du segment libre de size et on décale son start a += size
    	else if (seg_libre->start == start) 
    	{
        	seg_libre->start += size;
        	seg_libre->size -= size;
    	}
       
        // Cas ou ils se teminent au même emplacement (fin) : on  diminue le size du segment libre
    	else if (seg_libre->start + seg_libre->size == start + size) 
    	{
        	seg_libre->size -= size;
    	}
    
         // Cas ou le segment à cree se situe dans le segment libre (millieu)
    	else 
    	{
        	Segment *new_seg_fin = (Segment*)malloc(sizeof(Segment));// Alloue un nouveau segment pour la memoire libre qui reste devant la taille du segment cree 
        	if (!new_seg_fin) return 0; 

        	new_seg_fin->start = start + size; // Initialise son start à partir de la taille du segment cree 
        	new_seg_fin->size = (seg_libre->start + seg_libre->size)-(start+size); // Initialise la taille restante devant le semgent cree (DB = B - D)
        	new_seg_fin->next = seg_libre->next;// Le relie au segment devant le semgment libre

        	seg_libre->size = start - seg_libre->start; // Diminue la taille du segment derriere le segment cree
        	seg_libre->next = new_seg_fin;// le relie au nouveau segment allouer
			
    	}
    	return 1;
    }
	printf("Pas de place dispo impossible a cree\n");
    return 0;
}

int remove_segment(MemoryHandler *handler, const char *name)    
{
    //Suprime un segment du tableau de hashage : le reinserer dans free_lsit

    if (!handler || !name) return 0;

    Segment *segment_free = hashmap_get(handler->allocated, name);
    if (!segment_free) 
    {
        printf("Segment inconnu\n");
        return 0;
    }

    // Copie du segment avant de pouvoirs le supprimer
    Segment *new_seg = malloc(sizeof(Segment));
    if (!new_seg) return 0;
    *new_seg = *segment_free; 
    new_seg->next = NULL;

    //Supprime le segment
    hashmap_remove(handler->allocated, name);


    Segment *courant = handler->free_list;
    Segment *prec = NULL;

    if(handler->free_list==NULL)
    {
        // Cas ou free_list est vide
        handler->free_list = new_seg;
        return 0;
    }

    while (courant && courant->start < new_seg->start) 
    {
        // Parcours la memoire pour retrouver l'emplacement libre ou il doit êtres reinserer dans free_mist
        prec = courant;
        courant = courant->next;
    }


    if (prec==NULL)
    {
        // Cas tête
        if (new_seg->start + new_seg->size == courant->start)
        {
            // Cas ou la taille du segment liberer est adjacent à la tête : fusionne new_seg avec la tête de free_list
            new_seg->size += courant->size;
            new_seg->next = courant->next;
            free(courant); // libere la tetes
            handler->free_list = new_seg; // reafecte a new_seg
			return 1;
        }
        else
        {
            // Change la tête de free_list à new_seg
            new_seg->next = handler->free_list;
            handler->free_list = new_seg;
			return 1;
        }
    }
	else
    {
		//Reste on relie : prec----new_seg---courant
        new_seg->next = courant;
        prec->next = new_seg;

        if (prec->start + prec->size == new_seg->start) 
        {
            // Cas ou prec est adjacent à new_seg : fusionne prec et new_seg
            prec->size += new_seg->size;
            if (courant && (new_seg->start + new_seg->size == courant->start)) 
            {
                // Cas ou new_seg est adjacent à courant : fusionne new_seg et courant
                prec->size += courant->size;
                prec->next = courant->next;
                free(new_seg);
                free(courant);
                return 1;
            }
            prec->next = courant;
            free(new_seg);
            return 1;
        } 

        // Cas ou new_seg est adjacent à courant : fusionne new_seg et courant
        if (courant && (new_seg->start + new_seg->size == courant->start)) 
        {
            new_seg->size += courant->size;
            new_seg->next = courant->next;
            free(courant);
            return 1;
        }
    }

    return 1;
}

void destroy_memory_instruction(MemoryHandler *handler) 
{
    if (handler==NULL) return;

    Segment *cs = hashmap_get(handler->allocated, "CS");
    if (cs==NULL) return;


    for (int i = cs->start; i < cs->start + cs->size; i++) 
    {
        Instruction *instr = (Instruction *)handler->memory[i];
        if (instr) 
        {
            free(instr->mnemonic);
            free(instr->operand1);
            free(instr->operand2);
            free(instr);
            handler->memory[i] = NULL;
        }
    }
}

void destroy_handler(MemoryHandler *handler)
{
    // Libere MemoryHandler
    if (handler==NULL) 
		return;


    Segment *courant = handler->free_list;

    //Libere free_list
    while (courant) 
	{
        Segment *next = courant->next;
        free(courant);
        courant = next;
    }
    
     //Libere memory
    if (handler->memory)
     {
        Segment *cs = hashmap_get(handler->allocated, "CS");
        if (cs)
            destroy_memory_instruction(handler);
            
        for (int i = 0; i < handler->total_size; i++)
        {
            if (handler->memory[i])
                free(handler->memory[i]);
        }
        free(handler->memory);
     }

    //Libere le tableau de hashage
    hashmap_destroy(handler->allocated);
    
    free(handler);
}
