#include "HashMap.h"

unsigned long simple_hash(const char *str)
{
    // Fonction de hashage : somme des caracteres ascci de str
    unsigned long sum = 0;
    while (*str)
    {
        sum += (unsigned char)(*str);
        str++;
    }
    return sum % TABLE_SIZE;
}

HashMap *hashmap_create() 
{
    // Creer un hasmap

    HashMap *new = malloc(sizeof(HashMap));
    if (new == NULL) 
    {
        // Cas NULL
    	printf("erreur d'alloc hashmap");
        return NULL;  
    }

    // Initialise les champs
    new->size = 0;
    new->table = calloc(TABLE_SIZE, sizeof(HashEntry));
    if (new->table == NULL) 
    {
        free(new);  
        printf("erreur d'alloc hashentry");
        return NULL;  
    }

    return new;
}

int hashmap_insert(HashMap *map, const char *key, void *value)
{
    // Insere une HashEntry dans le tableau de hasahage

    if (map == NULL || key == NULL)
    {
        printf("Erreur : clé ou table de hachage NULL\n");
        return 0;
    }

    int position = simple_hash(key);
    int i = 0;

    while (i < TABLE_SIZE)
    {
        // Parcours le tableau de hashage table à partir de la clef key
        HashEntry *entry = &map->table[position];

        if (entry->key== NULL || entry->key == TOMBSTONE)
        {
            // Case vide : Insere la clef dans la case vide 
            entry->key = strdup(key);
            entry->value = value;
            map->size ++;

            return 1;  
        }
        else if (strcmp(entry->key, key) == 0)
    	{
        	// Clé existante : on libère l'ancienne valeur et on remplace
            if(entry->value)
        	    free(entry->value);
        	entry->value = value;
        	return 1;
    	}

        position = (position + 1) % TABLE_SIZE;
        i++;
    }

    printf("Table de hachage pleine\n");
    return 0; 
}

void* hashmap_get(HashMap *map, const char *key)
{
    // Rencoie la HashEntry à la position key 

    if (map == NULL || key == NULL) return NULL;// Cas NULL; 

    int position = simple_hash(key);
    int i = 0;

    while (i < TABLE_SIZE)
    {
        // Parcours le tableau de hashage table à partir la clef key 
        HashEntry *entry = &map->table[position];

        if (entry->key == NULL) 
        {
            // Cas ou la clef est NULL
        	printf("Erreur hashmap_get : clé non présente\n");
            return NULL;
		}

        if (entry->key != TOMBSTONE && strcmp(entry->key, key) == 0)
        {
            // Clef trouve 
            return entry->value;
		}
		
        position = (position + 1) % TABLE_SIZE;
        i++;
    }

    return NULL; 
}

int hashmap_remove(HashMap *map, const char *key)
{
    // Supprime la HashEntry à la positon key 
    
    if (map == NULL || key == NULL)
    {
        // Cas NULL
        printf("Erreur : clé ou table de hachage NULL\n");
        return 0;
    }

    int position = simple_hash(key);
    int i = 0;

    while (i < TABLE_SIZE)
    {
        // Parcours le tableau de hashage table à partir la clef key 
        HashEntry *entry = &map->table[position];

        if (entry->key == NULL)
        {
            // Case vide : rien à faire
            printf("case deja vide\n");
            return 0; 
        }

        if (entry->key != TOMBSTONE && strcmp(entry->key, key) == 0)
        {
            // Case non vide : on libere les champs key et value
            free(entry->key);
            free(entry->value);
            entry->key = TOMBSTONE; 
            entry->value = NULL;  
            map->size--;
            return 1;  
        }

        position = (position + 1) % TABLE_SIZE;
        i++;
    }

    return 0; 
}

void hashmap_destroy(HashMap *map)
{
    if (map == NULL) return; // Cas NULL

    for (int i = 0; i < TABLE_SIZE; i++)
    {
        // Parcours le tableau de hashage table 
        HashEntry *entry = (map->table+i);

        if (entry->key != NULL && entry->key != TOMBSTONE)
        {
            // Case non vide : on libere les champs key et value
            free(entry->key); 
            free(entry->value); 
        }
    }

    // Libere le tableau de hashage
    free(map->table);
    free(map);
}
//anissa.kheireddine@lip6.fr
void afficher_hashmap(HashMap *map) 
{
    if (!map) 
        return;
    
    for(int i = 0; i < TABLE_SIZE; i++) 
    {
        HashEntry *entry = &map->table[i];
        if(entry->key && entry->key != TOMBSTONE && entry->value) 
        {
            printf("|%s --> %d|\n", entry->key, *(int*)entry->value);
        }
    }
}



