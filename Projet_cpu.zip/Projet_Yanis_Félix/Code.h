#ifndef CODE_H
#define CDOE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <regex.h>
#include "Adressage.h"
#include "Stack.h"

int search_and_replace(char **str, HashMap *values);
int resolve_constants(ParserResult *result);
void allocate_code_segment(CPU *cpu, Instruction **code_instructions, int code_count);
int handle_instruction(CPU *cpu, Instruction *instr, void *src, void *dest);
int execute_instruction(CPU *cpu, Instruction *instr);
Instruction* fetch_next_instruction(CPU *cpu);
int run_program(CPU *cpu);
#endif