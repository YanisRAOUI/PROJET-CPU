#ifndef STACK_H
#define STACK_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <regex.h>
#include "Code.h"

int pushvalue(CPU *cpu, int value);
int pop_value(CPU *cpu, int *dest);

#endif