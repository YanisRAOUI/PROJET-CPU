#ifndef ADRESSAGE_H
#define ADRESSAGE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <regex.h>
#include "Cpu.h"

int matches (const char *pattern, const char *string);
void *immediate_addressing(CPU *cpu, const char *operand);
void *register_addressing(CPU *cpu, const char *operand);
void *memory_direct_addressing(CPU *cpu, const char *operand);
void *register_indirect_addressing(CPU *cpu, const char *operand);
void handle_MOV(CPU* cpu, void* src, void* dest);
CPU *setup_test_environment();
void affiche_registre(CPU *cpu);
void *resolve_addressing(CPU *cpu, const char *operand);

#endif